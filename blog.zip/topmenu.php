<div class="top-menu">
    <span class="menu"> </span>
    <ul>
        <li class="active"><a href="index.php">ГЛАВНАЯ</a></li>
        <li><a href="contact.html">КОНТАКТЫ</a></li>
        <li><a href="terms.html">ПРАВИЛА</a></li>
        <li><a href="adminpanel/index.php">АДМИН ПАНЕЛЬ</a></li>
        <div class="clearfix"> </div>
    </ul>
</div>