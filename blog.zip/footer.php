<div class="fotter">
    <div class="container">
        <div class="col-md-4 fotter-info">
            <h3>INTEGER VITAE LIBERO</h3>
            <p>Raesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate magna eros eu erat. Aliquam erat volutpat. </p>
            <p>Nam dui mi, tincidunt quis, accumsan porttitor, facilisis luctus, metus. Phasellus ultrices nulla quis nibh. Quisque a lectus. </p>
        </div>
        <div class="col-md-4 fotter-list">
            <h3>VESTIBULUM COMMO</h3>
            <ul>
                <li><a href="#">Ut alliquam solicitudin</a></li>
                <li><a href="#">Neque id cursus faucibus</a></li>
                <li><a href="#">Raesent dapibus neque id cursus</a></li>
            </ul>
        </div>
        <div class="col-md-4 fotter-media">
            <h3>FOLLOW US ON....</h3>
            <div class="social-icons">
                <a href="#"><span class="fb"> </span></a>
                <a href="#"><span class="twt"> </span></a>
                <a href="#"><span class="in"> </span></a>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>