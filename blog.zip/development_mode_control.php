<?php 
 error_reporting(E_ALL);
 ini_set('display_errors',1);
require_once("main_classes.php");
require_once ('cndata/cnct.php') ;
?>