<div class="col-md-4 content-main-right">
    <div class="search">
        <h3>SEARCH HERE</h3>
        <form>
            <input type="text" value="" onfocus="this.value=''" onblur="this.value=''">
            <input type="submit" value="">
        </form>
    </div>
    <div class="categories">
        <h3>CATEGORIES</h3>
        <li class="active"><a href="#">Donec quis dui at dolor tempor</a></li>
        <li><a href="#">Vestibulum commodo felis quis tort</a></li>
        <li><a href="#">Fusce pellentesque suscipit</a></li>
    </div>
    <div class="archives">
        <h3>ARCHIVES</h3>
        <li class="active"><a href="#">July 2014</a></li>
        <li><a href="#">June 2014</a></li>
        <li><a href="#">May 2014</a></li>
    </div>
</div>
