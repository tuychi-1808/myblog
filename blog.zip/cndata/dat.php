<?php
define('DBHost', 'localhost');
define('DBPort', 3306);
define('DBName', 'blog');
define('DBUser', 'root');
define('DBPassword', '');


// // Database Constants
// define("SRV", "localhost");
// define("USR", "eslatmauserpdo");
// define("PSS", "Abf369ff?!");
// define("NAM", "eslatmapdo");


$host = 'localhost';
$db   = 'blog';
$user = 'root';
$pass = '';
$charset = 'utf8';
?>
 